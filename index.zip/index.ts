enum Role {
  Admin = "Admin",
  User = "User",
  Manager = "Manager",
  Guest = "Guest"
}


class User {
  firstName: string;
  middleName: string | null;
  lastName: string;
  email: string;
  phoneNumber: string;
  role: Role;
  address: string;

  constructor(
    firstName: string,
    middleName: string | null,
    lastName: string,
    email: string,
    phoneNumber: string,
    role: Role,
    address: string
  ) {
    this.firstName = firstName;
    this.middleName = middleName;
    this.lastName = lastName;
    this.email = email;
    this.phoneNumber = phoneNumber;
    this.role = role;
    this.address = address;
  }
}

interface IUserService {
  getAll(): User[];
  reset(): void;
  add(user: User): void;
  update(index: number, user: User): void;
  delete(index: number): void;
}

const initialUsersJson = [
  {
    firstName: "John",
    middleName: "A.",
    lastName: "Doe",
    email: "john.doe@example.com",
    phoneNumber: "1234567890",
    role: Role.Admin,
    address: "123 Main St"
  },
  {
    firstName: "Jane",
    middleName: "",
    lastName: "Smith",
    email: "jane.smith@example.com",
    phoneNumber: "9876543210",
    role: Role.User,
    address: "456 Market Ave"
  },
  {
    firstName: "Alex",
    middleName: "K.",
    lastName: "Johnson",
    email: "alex.johnson@example.com",
    phoneNumber: "5551112222",
    role: Role.Manager,
    address: "789 Park Blvd"
  }
];


class UserService implements IUserService {
  private users: User[] = [];
  private originalUsers: User[] = [];

  constructor() {
    this.originalUsers = initialUsersJson.map(u => {
      return new User(
        u.firstName,
        u.middleName || null,
        u.lastName,
        u.email,
        u.phoneNumber,
        u.role,
        u.address
      );
    });

    this.reset();
  }

  getAll(): User[] {
    return [...this.users];
  }

  reset(): void {
    this.users = this.originalUsers.map(u => {
      return new User(
        u.firstName,
        u.middleName,
        u.lastName,
        u.email,
        u.phoneNumber,
        u.role,
        u.address
      );
    });
  }

  add(user: User): void {
    this.users.push(user);
  }

  update(index: number, user: User): void {
    if (index >= 0 && index < this.users.length) {
      this.users[index] = user;
    }
  }

  delete(index: number): void {
    if (index >= 0 && index < this.users.length) {
      this.users.splice(index, 1);
    }
  }
}


const userService = new UserService();
const loadBtn = document.getElementById("loadUsersBtn") as HTMLButtonElement;
const tableBody = document.getElementById("tableBody") as HTMLElement;


function renderTable(): void {
  const users = userService.getAll();
  tableBody.innerHTML = "";

  users.forEach((user, index) => {
    const row = document.createElement("tr");

    row.innerHTML = `
      <td>${user.firstName}</td>
      <td>${user.middleName || ""}</td>
      <td>${user.lastName}</td>
      <td>${user.email}</td>
      <td>${user.phoneNumber}</td>
      <td>${user.role}</td>
      <td>${user.address}</td>
      <td>
        <button class="edit-btn btn btn-primary fa fa-edit" data-index="${index}"></button>
        <button class="delete-btn btn btn-danger fa fa-trash-alt" data-index="${index}"></button>
      </td>
    `;

    tableBody.appendChild(row);
  });

  attachRowEvents();
}


function attachRowEvents(): void {
  const editBtns = document.querySelectorAll(".edit-btn");
  const deleteBtns = document.querySelectorAll(".delete-btn");

  editBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      const index = Number(btn.getAttribute("data-index"));
      enterEditMode(index);
    });
  });

  deleteBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      const index = Number(btn.getAttribute("data-index"));
      userService.delete(index);
      renderTable();
    });
  });
}


function enterEditMode(index: number): void {
  const users = userService.getAll();

  tableBody.innerHTML = "";

  users.forEach((user, i) => {
    const row = document.createElement("tr");

    if (i === index) {
      row.innerHTML = `
        <td><input name="firstName" value="${user.firstName}" /></td>
        <td><input name="middleName" value="${user.middleName || ""}" /></td>
        <td><input name="lastName" value="${user.lastName}" /></td>
        <td><input name="email" value="${user.email}" /></td>
        <td><input name="phoneNumber" value="${user.phoneNumber}" /></td>
        <td>
          <select name="role">
            ${Object.values(Role)
              .map(r => `<option value="${r}" ${r === user.role ? "selected" : ""}>${r}</option>`)
              .join("")}
          </select>
        </td>
        <td><input name="address" value="${user.address}" /></td>
        <td>
          <button class="save-btn btn btn-success " data-index="${i}">Save</button>
          <button class="cancel-btn btn btn-secondary" data-index="${i}">Cancel</button>  
        </td>
      `;
    } else {
      row.innerHTML = `
        <td>${user.firstName}</td>
        <td>${user.middleName || ""}</td>
        <td>${user.lastName}</td>
        <td>${user.email}</td>
        <td>${user.phoneNumber}</td>
        <td>${user.role}</td>
        <td>${user.address}</td>
        <td>
          <button class="edit-btn btn btn-primary fa fa-edit" data-index="${i}"></button>
          <button class="delete-btn btn btn-danger fa fa-trash-alt" data-index="${i}"></button>
        </td>
      `;
    }

    tableBody.appendChild(row);
  });

  const saveBtn = document.querySelector(".save-btn") as HTMLButtonElement;
  const cancelBtn = document.querySelector(".cancel-btn") as HTMLButtonElement;

 saveBtn?.addEventListener("click", (event) => {
  const button = event.currentTarget as HTMLButtonElement;
  const row = button.closest("tr") as HTMLTableRowElement;

 
  const inputs = row.querySelectorAll<HTMLInputElement>("input[name]");
  const select = row.querySelector<HTMLSelectElement>("select[name='role']")!;

  const updatedData: any = {};

  inputs.forEach((input) => {
    const fieldName = input.name; // Correct way to get name
    updatedData[fieldName] = input.value || null;
  });

  updatedData.role = select.value;

  const updatedUser = new User(
    updatedData.firstName,
    updatedData.middleName,
    updatedData.lastName,
    updatedData.email,
    updatedData.phoneNumber,
    updatedData.role as Role,
    updatedData.address
  );

  userService.update(index, updatedUser);
  renderTable();
});



  cancelBtn?.addEventListener("click", renderTable);

  attachRowEvents();
}


loadBtn.addEventListener("click", () => {
  userService.reset();
  renderTable();
  loadBtn.textContent = "Refresh data";
    document.getElementById("userTable")!.style.display = "table";
});
